# 無法上傳docker image - [連結](https://cloud.google.com/container-registry/docs/advanced-authentication)

- 登入權限: gcloud auth login
- docker倉庫紀錄: gcloud auth configure-docker
